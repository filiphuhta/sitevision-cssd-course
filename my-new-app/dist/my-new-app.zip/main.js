/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
define(function() { return /******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/***/ (function() {

eval("/*\nRemove when rendering severside app\n\nimport * as React from 'react';\nimport ReactDOM from 'react-dom';\nimport App from './components/App';\n\nexport default (initialState, el) => {\n  ReactDOM.hydrate(\n    <App message={initialState.message} name={initialState.name} />,\n    el\n  );\n};\n*///# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1uZXctYXBwLy4vc3JjL21haW4uanM/NTZkNyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLypcblJlbW92ZSB3aGVuIHJlbmRlcmluZyBzZXZlcnNpZGUgYXBwXG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuaW1wb3J0IEFwcCBmcm9tICcuL2NvbXBvbmVudHMvQXBwJztcblxuZXhwb3J0IGRlZmF1bHQgKGluaXRpYWxTdGF0ZSwgZWwpID0+IHtcbiAgUmVhY3RET00uaHlkcmF0ZShcbiAgICA8QXBwIG1lc3NhZ2U9e2luaXRpYWxTdGF0ZS5tZXNzYWdlfSBuYW1lPXtpbml0aWFsU3RhdGUubmFtZX0gLz4sXG4gICAgZWxcbiAgKTtcbn07XG4qLyJdLCJmaWxlIjoiLi9zcmMvbWFpbi5qcy5qcyIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/main.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/main.js"]();
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});;